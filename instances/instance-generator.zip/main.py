import file_manager
from graph_properties import BASE_STRUCTURE
from instance_generator import generate_graph, set_random_seed

output_folder = "instances/generated"

if __name__ == '__main__':
    set_random_seed(1234)
    for key, value in BASE_STRUCTURE.items():
        for i in range(value['amount']):
            fname = f'{key}-{i + 1}.in'
            print(f'generating case over file {fname}')
            g = generate_graph(value['config'])
            file_manager.write_instance(g, output_folder, fname)
            file_manager.write_instance_vicente(g, output_folder, "vicente_"+fname+".txt")
            print(f'case on file {fname} generated in {output_folder}')
