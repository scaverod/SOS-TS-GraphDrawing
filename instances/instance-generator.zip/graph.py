import networkx
from networkx import DiGraph, is_weakly_connected


def is_connected(structure):
    pass


class Graph(object):

    def __init__(self, num_vertices, num_layers):
        self.num_vertices = num_vertices
        self.num_edges = 0
        self.num_layers = num_layers
        self.num_vertices_in_layer = int(num_vertices / num_layers)
        self.structure = self.__generate_structure()
        self.adjacency_set = self.__init_adjacency_set()
        self.dummy_vertices = set()
        self.long_edges = []

    def __init_adjacency_set(self):
        adjacency_set = {}
        for h in range(len(self.structure)):
            for j in range(len(self.structure[h])):
                adjacency_set[self.structure[h][j]] = {"source": set(), "target": set(), "all": set()}
                if h != len(self.structure) - 1:
                    for v in self.structure[h + 1]:
                        adjacency_set[self.structure[h][j]]["all"].add(v)
                        adjacency_set[self.structure[h][j]]["target"].add(v)
                        self.num_edges += 1
                if h != 0:
                    for v in self.structure[h - 1]:
                        adjacency_set[self.structure[h][j]]["source"].add(v)
                        adjacency_set[self.structure[h][j]]["all"].add(v)
        return adjacency_set

    def __generate_structure(self):
        structure = []
        self.layer_of_vertex = {}
        for h in range(self.num_layers):
            structure.append([])
            for x in range(self.num_vertices_in_layer):
                v = x + 1 + self.num_vertices_in_layer * h
                structure[h].append(v)
                self.layer_of_vertex[v] = h
        return structure

    def remove_edge(self, source, target):
        if len(self.adjacency_set.get(source)["target"]) > 1 and len(self.adjacency_set.get(target)["source"]) > 1:
            self.adjacency_set.get(source)["target"].remove(target)
            self.adjacency_set.get(source)["all"].remove(target)
            self.adjacency_set.get(target)["source"].remove(source)
            self.adjacency_set.get(target)["all"].remove(source)
            self.num_edges -= 1

    def get_adjacent(self, vertex, type="target"):
        return self.adjacency_set.get(vertex)[type]

    def get_list_of_possible_long_edges(self):
        long_edges = []
        for h in range(len(self.structure) - 2):
            for j in self.structure[h]:
                long_edges_vertex = self.get_long_edges(j)
                long_edges_vertex = [x for x in long_edges_vertex if len(x) > 2]
                if len(long_edges_vertex) > 0:
                    long_edges.extend(long_edges_vertex)
        return long_edges

    def get_long_edges(self, vertex):
        resul = []
        for adjacent in self.get_adjacent(vertex, type="target"):
            if len(self.get_adjacent(adjacent, type="source")) <= 1 and len(
                    self.get_adjacent(adjacent, type="target")) <= 1:
                resul.append(self.get_recursive_long_edges([vertex, adjacent]))

        return resul

    def get_recursive_long_edges(self, actual_list):
        for adjacent in self.get_adjacent(actual_list[-1], type="target"):
            if len(self.get_adjacent(adjacent, type="source")) == 1 and len(
                    self.get_adjacent(adjacent, type="target")) <= 1:
                actual_list.append(adjacent)
                self.get_recursive_long_edges(actual_list)
            else:
                actual_list.append(adjacent)
        return actual_list

    def add_long_edge(self, long_edge):
        self.long_edges.append(long_edge)
        for v in long_edge[1:-1]:
            self.dummy_vertices.add(v)

    def is_dummy(self, vertex):
        return vertex in self.dummy_vertices

    def to_text(self):
        instance = f"{self.num_vertices} {self.num_edges} {self.num_layers} {len(self.long_edges)}\n"
        for h in range(len(self.structure)):
            for u in self.structure[h]:
                for v in self.get_adjacent(u, "target"):
                    instance += f"{u} {v}\n"
        for h in range(len(self.structure)):
            for u in self.structure[h]:
                instance += f"{u} "
            instance += "\n"
        for edge in self.long_edges:
            for u in edge:
                instance += f"{u} "
            instance += "\n"
        return instance


    def to_text_vicente(self):
        instance = f"{self.num_vertices} {self.num_edges} {self.num_layers} {len(self.long_edges)} 0\n"
        for h in range(self.num_layers):
            instance += f"{len(self.structure[h])} "
        instance += "\n"
        for h in range(len(self.structure)):
            for u in self.structure[h]:
                for v in self.get_adjacent(u, "target"):
                    instance += f"{u} {v}\n"
        for edge in self.long_edges:
            instance += f"{len(edge)} "
            for u in edge:
                instance += f"{u} "
            instance += "\n"
        return instance


    def is_valid(self):
        dg = self.to_nx_directed_graph()
        return is_weakly_connected(dg) and self.has_long_edges()


    def to_nx_directed_graph(self):
        dg = DiGraph()
        DiGraph.add_edges_from(dg, self.get_edges())
        networkx.freeze(dg)
        return dg

    def get_edges(self):
        list_of_edges = []
        for h in range(len(self.structure)):
            for u in self.structure[h]:
                for v in self.get_adjacent(u, "target"):
                    list_of_edges.append((u, v))
        return list_of_edges

    def has_long_edges(self):
        return len(self.long_edges) > 0
