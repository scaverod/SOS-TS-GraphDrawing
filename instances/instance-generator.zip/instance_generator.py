import random as rnd

from graph import Graph


def set_random_seed(seed):
    rnd.seed(seed)


# Vertices can't currently be in two long edges as source of target
def remove_long_edges_allowing_multiple_long_edges(list_of_long_edges, long_edge, remove_this=True):
    if remove_this:
        list_of_long_edges.remove(long_edge)
    to_remove = []
    dummy_vertices = long_edge[1:-1]
    for edge in list_of_long_edges:
        if not (set(dummy_vertices).isdisjoint(set(edge))):
            to_remove.append(edge)
    for i in to_remove:
        list_of_long_edges.remove(i)
    to_remove = []
    ending_vertices = [long_edge[0], long_edge[-1]]
    for edge in list_of_long_edges:
        possible_dummy_vertices = edge[1:-1]
        if not (set(ending_vertices).isdisjoint(set(possible_dummy_vertices))):
            to_remove.append(edge)
    for i in to_remove:
        list_of_long_edges.remove(i)


# Vertices can be as source of target of two long edges
def remove_long_edges(list_of_long_edges, long_edge, remove_this=True):
    if remove_this:
        list_of_long_edges.remove(long_edge)
    to_remove = []
    for edge in list_of_long_edges:
        if not (set(long_edge).isdisjoint(set(edge))):
            to_remove.append(edge)
    for i in to_remove:
        list_of_long_edges.remove(i)


def edges_to_remove(conf, h, num_vertices_in_layer):
    edges_to_remove_of_vertex = {}
    max_edges_to_remove = rnd.randrange(conf['A']['MIN'], conf['A']['MAX']) + 1
    for v in range(num_vertices_in_layer):
        n = num_vertices_in_layer - max(
            int((rnd.randrange(conf['A']['MIN'], max_edges_to_remove) / 100) * num_vertices_in_layer), 1)
        edges_to_remove_of_vertex[v + 1 + h * num_vertices_in_layer] = n
    return edges_to_remove_of_vertex


def generate_graph(conf):
    is_valid = False
    while is_valid is False:
        while True:
            num_layers = rnd.randrange(conf['NL']['MIN'], conf['NL']['MAX'] + 1)
            num_vertices_in_layer = rnd.randrange(conf['NVL']['MIN'], conf['NVL']['MAX'] + 1)
            num_vertices = num_vertices_in_layer * num_layers
            if conf['V']['MIN'] <= num_vertices <= conf['V']['MAX']:
                break
        g = Graph(num_vertices, num_layers)
        for h in range(num_layers - 1):
            edges_to_remove_of_vertex = edges_to_remove(conf, h, num_vertices_in_layer)
            while edges_to_remove_of_vertex:
                keys = list(edges_to_remove_of_vertex.keys())
                rnd.shuffle(keys)
                for key in keys:
                    adjacent_list = list(g.get_adjacent(key))
                    g.remove_edge(key, rnd.choice(adjacent_list))
                    if edges_to_remove_of_vertex[key] == 1:
                        del edges_to_remove_of_vertex[key]
                    else:
                        edges_to_remove_of_vertex[key] = edges_to_remove_of_vertex[key] - 1
        list_of_long_edges = g.get_list_of_possible_long_edges()
        num_long_edges = int(num_vertices * (rnd.randrange(conf['L']['MIN'], conf['L']['MAX'] + 1)) / 100)
        for _ in range(num_long_edges):
            if len(list_of_long_edges) < 1:
                break
            long_edge = rnd.choice(list_of_long_edges)
            g.add_long_edge(long_edge)
            remove_long_edges(list_of_long_edges, long_edge)
        is_valid = g.is_valid()
    return g
