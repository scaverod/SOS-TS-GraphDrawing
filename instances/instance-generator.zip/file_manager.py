import os


def write_instance(instance, path, name):
    if not os.path.exists(path):
        os.makedirs(path)
    f = open(path + "/" + name, "w")
    text = instance.to_text()
    f.write(text)
    f.close()


def write_instance_vicente(instance, path, name):
    path = path + "_vicente"
    if not os.path.exists(path):
        os.makedirs(path)
    f = open(path + "/" + name, "w")
    text = instance.to_text_vicente()
    f.write(text)
    f.close()
