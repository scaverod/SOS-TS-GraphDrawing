# Instances are classified into three groups: small, medium and large.
# For each instance the following values are randomly set:
# - V : Number of vertices
# - A : % of vertices of the next layer to which it will be connected
# - NL : number of layers
# - NVL: number of vertices in layer
# - L : % of vertices of vertices that could have long edges
#




BASE_STRUCTURE = {
    'small': {
        'amount': 0,
        'config': {
            'V': {
                'MIN': 9, 'MAX': 100
            },
            'A': {
                'MIN': 1, 'MAX': 50,
            },
            'NL': {
                'MIN': 3, 'MAX': 10
            },
            'NVL': {
                'MIN': 3, 'MAX': 10
            },
            'L': {
                'MIN': 10, 'MAX': 20
            }
        }
    },
    'medium': {
        'amount': 105,
        'config': {
            'V': {
                'MIN': 100, 'MAX': 250
            },
            'A': {
                'MIN': 1, 'MAX': 15,
            },
            'NL': {
                'MIN': 10, 'MAX': 20
            },
            'NVL': {
                'MIN': 10, 'MAX': 30
            },
            'L': {
                'MIN': 25, 'MAX': 50
            }
        }
    },
    'medium_dense': {
        'amount': 0,
        'config': {
            'V': {
                'MIN': 100, 'MAX': 250
            },
            'A': {
                'MIN': 15, 'MAX': 30,
            },
            'NL': {
                'MIN': 10, 'MAX': 20
            },
            'NVL': {
                'MIN': 10, 'MAX': 30
            },
            'L': {
                'MIN': 25, 'MAX': 50
            }
        }
    },
    'large': {
        'amount': 0,
        'config': {
            'V': {
                'MIN': 250, 'MAX': 600
            },
            'A': {
                'MIN': 1, 'MAX': 15,
            },
            'NL': {
                'MIN': 10, 'MAX': 80
            },
            'NVL': {
                'MIN': 10, 'MAX': 80
            },
            'L': {
                'MIN': 25, 'MAX': 75
            }
        }
    },
    'large_dense': {
        'amount': 0,
        'config': {
            'V': {
                'MIN': 250, 'MAX': 600
            },
            'A': {
                'MIN': 15, 'MAX': 30,
            },
            'NL': {
                'MIN': 10, 'MAX': 80
            },
            'NVL': {
                'MIN': 10, 'MAX': 80
            },
            'L': {
                'MIN': 25, 'MAX': 75
            }
        }
    }
}
